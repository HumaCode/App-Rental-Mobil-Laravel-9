

<?php $__env->startSection('heading'); ?>
<div class="row page-titles mx-0">
    <div class="col-sm-6 p-md-0">
        <div class="welcome-text">
            <h4>Testimoni</h4>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<!-- Datatable -->
<link href="<?php echo e(asset('backend')); ?>/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">

<style>
    table.dataTable tbody tr,
    table.dataTable tbody td {
        color: black;
    }

    table.dataTable thead th,
    table.dataTable thead td {
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">

            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="display" style="min-width: 845px">
                        <thead class="text-center table-dark">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Testimoni</th>
                                <th>Pesan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $testimoni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration); ?>.</td>

                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->testimoni); ?></td>
                                <td><?php echo e($item->message); ?></td>

                                <td class="text-center">

                                    <a href="<?php echo e(route('admin.delete_testimoni', $item->id)); ?>"
                                        class="btn btn-danger btn-sm btn-flat"
                                        onClick="return confirm('Yakin akan menghapus data ini?');"><i
                                            class="fa fa-edit"></i>&nbsp; Hapus</a>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<!-- Datatable -->
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/js/plugins-init/datatables.init.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App-Rental-Mobil-Laravel-9\resources\views/backend/testimoni.blade.php ENDPATH**/ ?>