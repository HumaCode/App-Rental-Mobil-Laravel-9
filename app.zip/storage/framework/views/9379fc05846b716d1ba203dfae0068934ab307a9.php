
<?php $__env->startSection('content'); ?>
    <!-- Contact Start -->
    <br><br>
    <div class="container-xxl py-5 mt-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                    <div class="banner_taital_main">
                        <h1 class="banner_taital">Kontak <span style="color: #40C0D8;">Kami</span>
                        </h1>
                        <h4><b>DAPATKAN PENAWARAN</b></h4>
                        <p class="banner_text">Rasakan kebebasan berkendara dengan rental mobil terbaik di kota ini!!<br><br>
                        </p>
                    </div>

                    <form action="<?php echo e(route('penawaran')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <label for="name">Nama Lengkap</label>
                                    <input type="text" class="form-control" name="name" id="name"
                                        placeholder="Nama Lengkap">
                                </div>
                            </div>


                            <div class="col-12 mt-2">
                                <div class="form-floating">
                                    <label for="message">Ada Yang Bisa Kami Bantu</label>
                                    <textarea class="form-control" placeholder="Ketikan disini.." name="message" id="message" style="height: 100px"></textarea>
                                </div>
                            </div>
                            <div class="col-12 mt-2">
                                
                                <button class="btn btn-primary py-3 px-4" type="submit" onclick="whatsapp()">Kirim
                                    Pesan</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s" style="min-height: 450px;">
                    <div class="position-relative rounded overflow-hidden h-100">
                        <?php echo $setting->location; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App-Rental-Mobil-Laravel-9\resources\views/user/kontak.blade.php ENDPATH**/ ?>