<?php
$setting = App\Models\Setting::findOrFail(1);
?>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo e($setting->title); ?> </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url($setting->logo)); ?>">
    <link href="<?php echo e(asset('backend')); ?>/vendor/pg-calendar/css/pignose.calendar.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend')); ?>/vendor/chartist/css/chartist.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend')); ?>/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">

    <?php echo $__env->yieldPushContent('css'); ?>
    <style>
        .nav-header .brand-title {
            max-width: 130px;
        }
    </style>

</head>

<body>

    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>

    <div id="main-wrapper">

        <?php echo $__env->make('backend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-body">
            <div class="container-fluid">

                <?php echo $__env->yieldContent('heading'); ?>

                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>

        <?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Required vendors -->
    <script src="<?php echo e(asset('backend')); ?>/vendor/global/global.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/quixnav-init.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/custom.min.js"></script>

    <script src="<?php echo e(asset('backend')); ?>/vendor/chartist/js/chartist.min.js"></script>
    <!-- App js-->
    <script src="<?php echo e(asset('backend')); ?>/js/validate.min.js"></script>

    <script src="<?php echo e(asset('backend')); ?>/vendor/moment/moment.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/vendor/pg-calendar/js/pignose.calendar.min.js"></script>


    <script src="<?php echo e(asset('backend')); ?>/js/dashboard/dashboard-2.js"></script>
    <!-- Circle progress -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        <?php if(Session::has('message')): ?>
            var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"
            switch (type) {
                case 'info':
                    toastr.info(" <?php echo e(Session::get('message')); ?> ");
                    break;

                case 'success':
                    toastr.success(" <?php echo e(Session::get('message')); ?> ");
                    break;

                case 'warning':
                    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
                    break;

                case 'error':
                    toastr.error(" <?php echo e(Session::get('message')); ?> ");
                    break;
            }
        <?php endif; ?>
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH C:\laragon\www\App-Rental-Mobil-Laravel-9\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>