

<?php
$merek = App\Models\BrandMobil::count();
$mobil = App\Models\Mobil::count();
?>

<?php $__env->startSection('heading'); ?>
<div class="row page-titles mx-0">
    <div class="col-sm-6 p-md-0">
        <div class="welcome-text">
            <h4>Halo, Selamat Datang Kembali!</h4>
            <p class="mb-0"><?php echo e(auth()->user()->name); ?></p>
        </div>
    </div>

    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-6 col-sm-6">
        <div class="card">
            <div class="stat-widget-one card-body">
                <div class="stat-icon d-inline-block">
                    <i class="ti-layout-grid2 text-pink border-pink"></i>
                </div>
                <div class="stat-content d-inline-block">
                    <div class="stat-text">Merek Mobil</div>
                    <div class="stat-digit"><?php echo e($merek); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-sm-6">
        <div class="card">

            <div class="stat-widget-one card-body">
                <div class="stat-icon d-inline-block">
                    <i class="ti-car text-success border-success"></i>
                </div>
                <div class="stat-content d-inline-block">
                    <div class="stat-text">Daftar Mobil</div>
                    <div class="stat-digit"><?php echo e($mobil); ?></div>
                </div>
            </div>


        </div>
    </div>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rental_mobil\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>