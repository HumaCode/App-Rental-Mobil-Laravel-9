<div class="nav-header">
    <a href="index.html" class="brand-logo">
        
        <img class="logo-abbr" src="<?php echo e(url($setting->logo)); ?>" alt="">
        <img class="logo-compact" src="<?php echo e(asset('backend')); ?>/images/logo-text.png" alt="">
        <img class="brand-title" src="<?php echo e(url($setting->logo)); ?>" alt="">
    </a>

    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rental_mobil\resources\views/backend/layouts/nav.blade.php ENDPATH**/ ?>