<h1>Cara clone kodingan</h1><br>

- Clone kodingan <br>
- lakukan composer update <br>
- ubah file .env.example menjadi .env<br>
- buat database, kemudian koneksikan di dalam file .env <br>
- lakukan perintah php artisan key:generate <br>
- lakukan migrate dan seed php artisan migrate --seed
