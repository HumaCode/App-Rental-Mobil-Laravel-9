(function($) {
    "use strict"

    new quixSettings({
        version: "light"
    });


})(jQuery);